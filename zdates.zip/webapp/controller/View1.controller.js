sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",

], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("zdateszdates.controller.View1", {
		onInit: function() {
			// var oJsonModel = new sap.ui.model.json.JSONModel();
			// oJsonModel.loadData("model/data.json");
			// this.getView().byId("tableId").setModel(oJsonModel);
			var that = this;
			var sUrl = "/sap/opu/odata/sap/ZTIMESHEET_SRV";
			this.oDataModel = new sap.ui.model.odata.ODataModel(sUrl);
			this.getView().setModel(this.oDataModel);
			var oJsonModel = this.getOwnerComponent().getModel("tableModel"); //Deleted
			var oEntity = "/TimeSheetSet?$filter=Zuser eq '" + 10916065 + "'";
			var oGlobModel = this.getOwnerComponent().getModel("globModel");
			var curDate = new Date();
			that = this;
			oGlobModel.setProperty("/startDate", this.getDateStr(curDate));
			this.oDataModel.read(oEntity, null, null, false, function(data) {
				oJsonModel.setData(data); // Deleted
				that.getView().getModel().oData = data;
				that.getView().setModel(oJsonModel, "tableModel"); // Deleted
			}, function(oError) {

			});

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("First").attachMatched(this._onRouteMatched, this);

		},

		_onRouteMatched: function() {
			this.getView().getModel().refresh();
			this.getView().byId("tableId").getBinding("items").refresh(true);
		},
		weekPress: function(evt) {
			// var oSource = evt.getSource();
			// var oDate = oSource._getFocusedDate().getDate();
			// 	MessageBox.show("You have Clicked on");
		},

		onDateSelect: function(evt) {

		},

		createPress: function(evt) {
			var tmp = [];
			var s = this.byId("BiWeeklyCalendar").getSelectedDates();
			if (s.length === 0) {
				sap.m.MessageToast.show("Please select a Date", {
					duration: 3000, // default
					width: "15em", // default
					my: "center bottom", // default
					at: "center bottom", // default
					of: window // default
				});
			} else {
				for (var i = 0; i < s.length; i++) {
					tmp[i] = s[i].getProperty("startDate");
					tmp[i] = this.getDateString(tmp[i]);
				}
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Create");
				this.getOwnerComponent().getModel("globModel").setProperty("/selectedDates", tmp);

			}

		},

		deletePress: function(evt) {

		},

		onDatSelect: function(evt) {
			var selectedDate = evt.getSource()._oSelectedMonth.getDate();
			this.getDateStr(selectedDate);
		},

		getDateString: function(selectedDate) {
			selectedDate = selectedDate.toDateString();
			return selectedDate;
		},

		getDateStr: function(date) {
			return "" + date.getFullYear() + ("" + (date.getMonth() + 101)).substring(1) + ("" + (date.getDate() + 100)).substring(1);
		},

		itemPress: function(evt) {

		},

		onItemSelect: function(evt) {

		},
		listItemPress: function(evt) {
			var oItem = evt.getSource();
			var oContext = oItem.getBindingContext("tableModel");
			oContext = oContext.getPath();
			oContext = oContext.replace("/results/", "");
			oContext.trim();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Second", {
				data: oContext
			});
		}
	});
});