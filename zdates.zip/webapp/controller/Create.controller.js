sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast"
], function(Controller, Fragment, MessageToast) {
	"use strict";

	return Controller.extend("zdateszdates.controller.Create", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zdateszdates.view.Create
		 */
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Create").attachMatched(this._onRouteMatched, this);
			this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			this.getView().setModel(this.getOwnerComponent().getModel("tableModel"));
		},

		_onRouteMatched: function(evt) {
			var a = this.getOwnerComponent().getModel("globModel").getData().selectedDates;
			var oTitle = "";
			if (a.length > 1) {
				oTitle = this.oBundle.getText("multipleDates_Header_Text", [this.formatDateMMMDD(new Date(a[0])), a.length - 1]);
				this.getView().byId("simpleFormreateId").setTitle(oTitle);
				this.getView().byId("datePickerC").setVisible(false);

			} else {
				oTitle = this.oBundle.getText("singleDate_Header_Text", [this.formatDateMMMDD(new Date(a[0]))]);
				this.getView().byId("simpleFormreateId").setTitle(oTitle);
				this.getView().byId("datePickerC").setEnabled(false);
				this.getView().byId("datePickerC").setVisible(true);
			}
			var oDate = new Date(a[0]);
			this.getView().byId("datePickerC").setDateValue(oDate);
			this.getView().byId("zuserIdC").setText("10916065");
		},
		_formFragments: {},

		_getFormFragment: function(sFragmentName) {
			var oFormFragment = this._formFragments[sFragmentName];
			if (oFormFragment) {
				return oFormFragment;
			}

			oFormFragment = sap.ui.xmlfragment("zdateszdates.view." + sFragmentName, this);
			this._formFragments[sFragmentName] = oFormFragment;
			return this._formFragments[sFragmentName];
		},

		savePress: function(evt) {
			var data = {};
			data.Zuser = "10916065";
			data.Project = "COMAU";
			// data.Zuser = this.getView().byId("zuserIdC").getText(); Have to uncomment this.....
			data.RicefId = this.getView().byId("ricefIdC").getValue();
			data.RicefType = this.getView().byId("ricefTypeIdC").getSelectedKey();
			data.Ztype = this.getView().byId("typeIdC").getSelectedKey();
			data.Ztask = this.getView().byId("taskIdC").getSelectedKey();
			data.Zcomplexity = this.getView().byId("complexityC").getSelectedKey();
			data.Zstatus = this.getView().byId("statusIdC").getSelectedKey();
			data.Zdate = this.getView().byId("datePickerC").getDateValue();
			data.Zhours = this.getView().byId("hoursIdC").getValue();
			// var ToDatesInternalTable = {
			// 	"results": [{
			// 		"Alldates": " ",
			// 		"Zuser": " "
			// 	}]

			// };
			var ToDatesInternalTable = [];
			var sUrl = "/sap/opu/odata/sap/ZTIMESHEET_SRV";
			var oGlobModel = this.getOwnerComponent().getModel("globModel");
			var s = oGlobModel.getData().selectedDates;
			for (var i = 0; i < s.length; i++) {
				s[i] = new Date(s[i]);
				ToDatesInternalTable.push({
					Alldates: s[i],
					Zuser: "10916065"
				});
			}
			data.ToDatesInternalTable = ToDatesInternalTable;
			var oDataModelC = new sap.ui.model.odata.ODataModel(sUrl, true);
			var oEntity = "/TimeSheetSet"; // 10916065
			oDataModelC.create(oEntity, data, {
				success: function(oData) {
					MessageToast.show("Created...!!!");
				},
				error: function(oError) {
					MessageToast.show("Error...!!!");
				}
			});

		},

		getDateString: function(selectedDate) {
			selectedDate = selectedDate.toDateString();
			return selectedDate;
		},

		onNavPress: function(evt) {
			this.getView().byId("zuserIdC").setText(" ");
			this.getView().byId("ricefIdC").setValue(" ");
			this.getView().byId("taskIdC").setSelectedKey(" ");
			this.getView().byId("ricefTypeIdC").setSelectedKey(" ");
			this.getView().byId("typeIdC").setSelectedKey(" ");
			this.getView().byId("complexityC").setSelectedKey(" ");
			this.getView().byId("statusIdC").setSelectedKey(" ");
			this.getView().byId("datePickerC").setValue(" ");
			this.getView().byId("hoursIdC").setValue(" ");
			this.getOwnerComponent().getModel("tableModel").refresh();
			sap.ui.core.UIComponent.getRouterFor(this).navTo("First");
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf zdateszdates.view.Create
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zdateszdates.view.Create
		 */
		onAfterRendering: function(evt) {},

		formatDateMMMDD: function(d) {
			var m = d.getMonth();
			var a = d.getDate();
			var b = this.oBundle.getText("MONTH_" + m) + " " + a;
			return b;
		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zdateszdates.view.Create
		 */
		//	onExit: function() {
		//
		//	}

	});

});