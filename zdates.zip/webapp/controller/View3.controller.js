sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast"
], function(Controller, Fragment, MessageToast) {
	"use strict";

	return Controller.extend("zdateszdates.controller.View3", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf zdateszdates.view.View3
		 */
		onInit: function() {
			// this._showFormFragment("Display");
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Second").attachMatched(this._onRouteMatched, this);
			this.getView().setModel(this.getOwnerComponent().getModel("tableModel"));

		},

		_onRouteMatched: function(evt) {
			var oArgs = evt.getParameter("arguments");
			var oView = this.getView();
			var oPath = "/results/" + oArgs.data;
			var oGlobModel = this.getOwnerComponent().getModel("globModel");
			oGlobModel.setProperty("/oPath", oArgs.data);
			oView.bindElement(oPath);
			// Show the appropriate action buttons
			oView.byId("edit").setVisible(!false);
			oView.byId("save").setVisible(false);
			oView.byId("cancel").setVisible(false);
			this._showFormFragment("Test");
		},

		onNav: function(evt) {
			var oView = this.getView();
			oView.byId("edit").setVisible(true);
			oView.byId("save").setVisible(false);
			oView.byId("cancel").setVisible(false);
			// this._showFormFragment("Test");
			sap.ui.core.UIComponent.getRouterFor(this).navTo("First");
		},

		_onBindingChange: function(evt) {
			if (!this.getView().getBindingContext()) {
				this.getRouter().getTargets().display("notfound");
			}
		},

		handleEditPress: function(evt) {
			var oPath = this.getView().getModel("globModel").getProperty("/oPath");
			this.cloneData = this.getView().getModel().getData().results[oPath];
			this._toggleButtonsAndView(true);
		},

		handleSavePress: function(evt) {
			var data = {};
			data.Zuser = sap.ui.core.Fragment.byId("fragmentId", "userIdChange").getText();
			data.Project = sap.ui.core.Fragment.byId("fragmentId", "projectIdChange").getText();
			data.RicefId = sap.ui.core.Fragment.byId("fragmentId", "ricefIdChange").getValue();
			data.RicefType = sap.ui.core.Fragment.byId("fragmentId", "ricefTypeIdChange").getSelectedKey();
			data.Ztype = sap.ui.core.Fragment.byId("fragmentId", "typeIdChange").getSelectedKey();
			//
			data.Ztask = sap.ui.core.Fragment.byId("fragmentId", "taskIdChange").getSelectedKey();
			data.Zcomplexity = sap.ui.core.Fragment.byId("fragmentId", "complexityIdChange").getSelectedKey();
			data.Zstatus = sap.ui.core.Fragment.byId("fragmentId", "statusIdChange").getSelectedKey();
			data.Zdate = sap.ui.core.Fragment.byId("fragmentId", "dateIdChange").getDateValue();
			data.Zhours = sap.ui.core.Fragment.byId("fragmentId", "hoursIdChange").getValue();

			var sUrl = "/sap/opu/odata/sap/ZTIMESHEET_SRV";
			var oDataModelChange = new sap.ui.model.odata.ODataModel(sUrl, true);
			var oEntity = "/TimeSheetSet('10916065')";
			oDataModelChange.update(oEntity, data, {
				success: function(oData,oError) {
					MessageToast.show("Change...!!!");
				},
				error: function(oResponse,oError) {
					MessageToast.show("Error...!!!");
				}
			});
		},

		handleCancelPress: function(evt) {
			var oModel = this.getView().getModel();
			var oData = oModel.getData();
			var oPath = this.getView().getModel("globModel").getProperty("/oPath");
			oData.results[oPath] = this.cloneData;
			oModel.setData(oData);
			this._toggleButtonsAndView(false);
		},

		_toggleButtonsAndView: function(bEdit) {
			var oView = this.getView();
			// Show the appropriate action buttons
			oView.byId("edit").setVisible(!bEdit);
			oView.byId("save").setVisible(bEdit);
			oView.byId("cancel").setVisible(bEdit);

			// Set the right form type
			this._showFormFragment(bEdit ? "Change" : "Test");

		},

		_showFormFragment: function(sFragmentName) {
			var oPage = this.byId("idPage");
			oPage.removeAllContent();
			oPage.insertContent(this._getFormFragment(sFragmentName));
		},
		_formFragments: {},

		_getFormFragment: function(sFragmentName) {
				var oFormFragment = this._formFragments[sFragmentName];
				if (oFormFragment) {
					return oFormFragment;
				}
			 if(sFragmentName == "Test"){
				oFormFragment = sap.ui.xmlfragment("fragmentIdDisplay", "zdateszdates.view." + sFragmentName, this); 	
			 }else{
			 	oFormFragment = sap.ui.xmlfragment("fragmentId", "zdateszdates.view." + sFragmentName, this);
			 }
				this._formFragments[sFragmentName] = oFormFragment;
				return this._formFragments[sFragmentName];
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf zdateszdates.view.View3
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf zdateszdates.view.View3
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf zdateszdates.view.View3
		 */
		//	onExit: function() {
		//
		//	}

	});

});